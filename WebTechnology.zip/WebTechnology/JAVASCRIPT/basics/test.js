console.log(a);
let a;
