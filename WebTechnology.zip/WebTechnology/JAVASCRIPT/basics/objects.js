// //  Object Literals
// let l1 = {};
// console.log(l1, typeof l1);

// // Object Constructor
// let l2 = new Object()
// console.log(l2, typeof l2);

// let u1 = {};
// u1.uid = 101;
// u1.uname = "gyana";
// console.log(u1);

// let u2 = { uid: 102, uname: "somu" };
// console.log(u2);
// u2.uid = 101;
// u2.uname = "gyana";
// console.log(u2);

// let a = 10;
// console.log(a);
// let b = a;
// console.log(b);
// b = 20;
// console.log(b);

// let s1 = { id: 101, sname: "chinu", city: "Odisha" };
// console.log(s1);
// let s2 = s1;
// console.log(s2);

// s2.city = "Banglore";
// console.log(s2);
// console.log(s1);

// function sum(a, b) {
//   console.log(a + b);
// }
// function sum(a, b, c) {
//   console.log(a + b + c);
// }

// var b;
// console.log(b);

// let a;
// console.log(a);

// let demo = () => {
//   let d = 10;
// };
// console.log(demo());

// function sum() {
//     let res = 0
//     rec = 10+20
// }
// console.log(sum());

// let a = 10
{
  // let a = 20
  {
    // let a = 30
    {
      // let a = 40
      console.log(a);
      
    }
  }
}




















