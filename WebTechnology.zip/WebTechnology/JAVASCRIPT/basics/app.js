 function calc(num1, num2){
            console.log(num1+num2);
        }
        calc(5, "5");
        console.log(5+"5");